import requests

YANDEX_API_URL = "https://llm.api.cloud.yandex.net/foundationModels/v1/completion"
FOLDER_ID = "b1g5ripc3uv89hkrjo85"


def generate_answer(
    question: str,
    context: str,
    api_key: str
) -> str:

    payload = {
        "modelUri": f"gpt://AQVNxYb1Sz0huu7nJ3TgKiOFNfsByzh3MMFO6nwC/yandexgpt-lite/latest",
        "completionOptions": {
            "stream": False,
            "temperature": 0.3,
            "maxTokens": 500
        },
        "messages": [
            {
                "role": "system",
                "text": "Отвечай строго на основе предоставленного текста."
            },
            {
                "role": "user",
                "text": f"""
Дай ответ на данный вопрос, используя информацию из текста.

Вопрос:
{question}

Текст:
{context}
"""
            }
        ]
    }

    response = requests.post(
        YANDEX_API_URL,
        headers={
            "Content-Type": "application/json",
            "Authorization": f"Api-Key {api_key}"
        },
        json=payload
    )

    return response.json()["result"]["alternatives"][0]["message"]["text"]
