from typing import List, Tuple
from db.models import Text
from db.api.EmbeddingUtils import EmbeddingUtils


def get_query_embedding(question: str):
    return EmbeddingUtils.get_embedding(question)


def semantic_search(
    query_embedding,
    top_k: int = 3
) -> List[Tuple[float, Text]]:
    results = []

    for text in Text.objects.exclude(embedding__isnull=True):
        score = EmbeddingUtils.cos_compare(
            query_embedding,
            text.embedding
        )
        results.append((score, text))

    results.sort(key=lambda x: x[0], reverse=True)
    return results[:top_k]
