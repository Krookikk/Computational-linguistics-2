from rag.rag_search import (
    get_query_embedding,
    semantic_search
)
from rag.rag_generation import generate_answer
from db.api.EmbeddingUtils import EmbeddingUtils


def build_context(texts):
    return "\n\n".join(t.content for _, t in texts)


def rag_answer(
    question: str,
    api_key: str,
    n: int = 3,
    m: int = 2
) -> str:

    # -------- ФАЗА 2 --------
    query_embedding = get_query_embedding(question)
    top_n = semantic_search(query_embedding, top_k=n)
    context_n = build_context(top_n)

    answer_n = generate_answer(
        question=question,
        context=context_n,
        api_key=api_key
    )

    # -------- ФАЗА 3 --------
    answer_embedding = EmbeddingUtils.get_embedding(answer_n)
    top_m = semantic_search(answer_embedding, top_k=m)

    merged = {t.id: t for _, t in (top_n + top_m)}
    final_context = "\n\n".join(t.content for t in merged.values())

    final_answer = generate_answer(
        question=question,
        context=final_context,
        api_key=api_key
    )

    return final_answer
