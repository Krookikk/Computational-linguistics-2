import json
from pathlib import Path
from db.models import Text, Corpus
from rag.node_to_text import node_to_text


def ontology_loader(json_path: str):
    with open(json_path, encoding="utf-8") as f:
        data = json.load(f)

    corpus, _ = Corpus.objects.get_or_create(
        name="Основная онтология"
    )

    for node in data["nodes"]:
        content = node_to_text(node)

        Text.objects.create(
            name=node.get("name"),
            content=content,
            corpus=corpus
        )
