def node_to_text(node: dict) -> str:
    lines = []

    lines.append(f"Название: {node.get('name')}")
    lines.append(f"Имеет тип: {node.get('type')}")

    for attr, value in node.get("attributes", {}).items():
        lines.append(f"{attr}: {value}")

    for rel in node.get("relations", []):
        lines.append(
            f"{rel['type']}: {rel['target']}"
        )

    return "\n".join(lines)
